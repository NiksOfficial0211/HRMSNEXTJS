import { clsx, type ClassValue } from "clsx"

export function cn(...inputs: ClassValue[]) {
  return null
}
