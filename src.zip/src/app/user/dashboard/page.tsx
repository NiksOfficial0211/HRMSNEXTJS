// User dashboard

'use client'
import React, { useEffect, useRef, useState } from 'react'
import LeapHeader from '../../components/header'
import LeftPannel from '../../components/leftPannel';
import { useRouter } from 'next/navigation';
import Footer from '../../components/footer';
import { useGlobalContext } from '../../contextProviders/loggedInGlobalContext';
import { clientAdminDashboard } from '../../pro_utils/stringConstants';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation } from 'swiper/modules';

import ShowAlertMessage from '@/app/components/alert'

interface userPermissionModel {
    permission_id: '',
    is_allowed: false
}
// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import GreetingBlock from '@/app/components/userGreetingBlock';
import UserAttendanceTimer from '@/app/components/userAttendanceTimer';
import { CustomerLeavePendingCount } from '@/app/models/leaveModel';
import moment from 'moment';
import { pageURL_userAnnouncement, pageURL_userApplyLeaveForm, pageURL_userAsset, pageURL_userDoc, pageURL_userFillTask, pageURL_userSupportForm, pageURL_userTeamLeave } from '@/app/pro_utils/stringRoutes';
import { AttendanceTimer } from '@/app/models/userDashboardModel';
import { buildStyles, CircularProgressbar } from 'react-circular-progressbar';

const Dashboard = () => {
    const router = useRouter();
    const [scrollPosition, setScrollPosition] = useState(0);
    const [isBeginning, setIsBeginning] = useState(true);
    const [isEnd, setIsEnd] = useState(false);
    const swiperRef = useRef<any>(null);
    const [isLoading, setLoading] = useState(false);
    const [balancearray, setBalanceLeave] = useState<CustomerLeavePendingCount[]>([]);
    const [holidays, setHolidays] = useState<any[]>([]);
    const [empSalarySlip, setSalarySlip] = useState<LeapCustomerDocument[]>([]);
    const [permissionData, setPermissionData] = useState<userPermissionModel[]>();
    const { contaxtBranchID, contextClientID, contextRoleID,
        contextUserName, contextCustomerID, contextEmployeeID, contextLogoURL, contextProfileImage,
        contextCompanyName, dashboard_notify_activity_related_id, dashboard_notify_cust_id, setGlobalState } = useGlobalContext();
    const [announcementData, setAnnouncementData] = useState<userPermissionModel[]>();

    const [loadingCursor, setLoadingCursor] = useState(false);
    const [tabSelectedIndex, setTabSelectedIndex] = useState(0);
    const [attendanceData, setAttendanceData] = useState<AttendanceTimer>();

    const [showAlert, setShowAlert] = useState(false);
    const [alertForSuccess, setAlertForSuccess] = useState(0);
    const [alertTitle, setAlertTitle] = useState('');
    const [alertStartContent, setAlertStartContent] = useState('');
    const [alertMidContent, setAlertMidContent] = useState('');
    const [alertEndContent, setAlertEndContent] = useState('');
    const [alertValue1, setAlertValue1] = useState('');
    const [alertvalue2, setAlertValue2] = useState('');


    useEffect(() => {

        fetchDashboard();
        // const intervalId = setInterval(() => {
        //     // fetchActivities();
        //     fetchData();
        // }, 5000); // Call fetchActivities every 5 seconds

        const handleScroll = () => {
            setScrollPosition(window.scrollY); // Update scroll position
            const element = document.querySelector('.mainbox');
            if (window.pageYOffset > 0) {
                element?.classList.add('sticky');
            } else {
                element?.classList.remove('sticky');
            }
        };
        window.addEventListener('scroll', handleScroll);
        return () => {
            // clearInterval(intervalId);
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const fetchDashboard = async () => {
        setLoading(true);
        try {
            const formData = new FormData();
            formData.append("client_id", contextClientID);
            formData.append("branch_id", contaxtBranchID);
            formData.append("customer_id", contextCustomerID);
            formData.append("role_id", contextRoleID);

            const res = await fetch("/api/clientAdmin/dashboard", {
                method: "POST",
                body: formData,
            });
            if (res.ok) {
                const response = await res.json();
                setHolidays(response.upcommingHolidays.holidays);
                setBalanceLeave(response.myLeaveBalances.customerLeavePendingCount);
                setSalarySlip(response.my_documents[0]);
                setAttendanceData(response.myattendance[0]);
                setAnnouncementData(response.announcements[0]);
            } else {
                setLoading(false);
                setShowAlert(true);
                setAlertTitle("Error")
                setAlertStartContent("Failed to load dashboard");
                setAlertForSuccess(2)
            }
        } catch (error) {
            setLoading(false);
            console.error("Error fetching user data:", error);
            setShowAlert(true);
            setAlertTitle("Exception")
            setAlertStartContent("Failed to load");
            setAlertForSuccess(2)
        }
    };

    const checkPermission = (permissionId: any) => {
        if (permissionData) {
            for (let i = 0; i < permissionData?.length; i++) {
                if (permissionData[i].permission_id === permissionId) {
                    return permissionData[i].is_allowed;
                }
            }
        }
    }
    return (
        <div className='mainbox'>
            <header>
                <LeapHeader title={clientAdminDashboard} />
            </header>
            <LeftPannel menuIndex={20} subMenuIndex={0} showLeftPanel={true} rightBoxUI={
                <div>
                    {/* <LoadingDialog isLoading={isLoading} /> */}
                    {showAlert && <ShowAlertMessage title={alertTitle} startContent={alertStartContent} midContent={alertMidContent && alertMidContent.length > 0 ? alertMidContent : ""} endContent={alertEndContent} value1={alertValue1} value2={alertvalue2} onOkClicked={function (): void {
                        setShowAlert(false)
                    }} onCloseClicked={function (): void {
                        setShowAlert(false)
                    }} showCloseButton={false} imageURL={''} successFailure={alertForSuccess} />}
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-9">
                                <div className="new_user_dashbord_leftbox">
                                    <div className="new_user_left_firstmainbox">
                                        < GreetingBlock />
                                        {attendanceData && < UserAttendanceTimer data={attendanceData} />}
                                    </div>
                                    <div className="new_user_btns">
                                        <a href={pageURL_userAnnouncement}>
                                            <div className="new_user_btnlist new_user_btnlist_announcement">
                                                <div className="new_user_btnlist_left">
                                                    <img src="/images/user/megaphone.gif" alt="Assets Icon" className="img-fluid" />
                                                </div>
                                                <div className="new_user_btnlist_right">
                                                    Announcement
                                                </div>
                                                <div className="new_user_announcement_countbox">
                                                    2
                                                </div>
                                            </div>
                                        </a>
                                        <a href="#">
                                            <div className="new_user_btnlist">
                                                <div className="new_user_btnlist_left">
                                                    <img src="/images/user/salaryslip.gif" alt="Salary Slip Icon" className="img-fluid" />
                                                </div>
                                                <div className="new_user_btnlist_right">
                                                    Salary Slip
                                                </div>
                                            </div>
                                            {/* <div className="salery_slip_btn_box">
                                                <div className="salery_slip_btn_left">
                                                    <img src="/images/user/salaryslip.gif" alt="Salary Slip Icon" style={{ maxWidth: "45px", padding: "1px 1px 0px 7px" }} className="img-fluid" />
                                                </div>
                                                <div className="salery_slip_btn_right"><span>SALARY</span> SLIP</div>
                                            </div> */}
                                        </a>
                                        {/* }  */}
                                        {/* {checkPermission(permission_m_asset_6) && */}
                                        <a href={pageURL_userAsset}>
                                            <div className="new_user_btnlist">
                                                <div className="new_user_btnlist_left">
                                                    <img src="/images/user/asset.gif" alt="Assets Icon" className="img-fluid" />
                                                </div>
                                                <div className="new_user_btnlist_right">
                                                    My Assets
                                                </div>
                                            </div>
                                        </a>
                                        {/* }  */}

                                        {/* {checkPermission(permission_m_document_8) && */}
                                        <a href={pageURL_userDoc}>
                                            <div className="new_user_btnlist">
                                                <div className="new_user_btnlist_left">
                                                    <img src="/images/user/document.gif" alt="Documents Icon" className="img-fluid" />
                                                </div>
                                                <div className="new_user_btnlist_right">
                                                    Documents
                                                </div>
                                            </div>
                                        </a>
                                        {/* }  */}
                                        {/* {checkPermission(permission_m_help_10) && */}
                                        <a href={pageURL_userSupportForm}>
                                            <div className="new_user_btnlist">
                                                <div className="new_user_btnlist_left">
                                                    <img src="/images/user/help.gif" alt="Help Icon" className="img-fluid" />
                                                </div>
                                                <div className="new_user_btnlist_right">
                                                    Need Help
                                                </div>
                                            </div>

                                        </a>
                                        {/* } */}
                                    </div>
                                    {/* {checkPermission(permission_m_leave_7) && */}
                                    <div className="new_user_left_fourthmainbox">
                                        <div className="new_user_fourth_leftbox">
                                            {/* ---- */}
                                            <div className="nw_my_sweeper_btn_mainbox">
                                                <div className="swiper-button-prev-custom">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 405.333 405.333">
                                                        <circle cx="202.667" cy="202.667" r="202.667" fill="#fff" transform="matrix(.71 0 0 .71 58.773 58.773)" />
                                                        <path fill="#7492a9" d="M405.332 202.664C405.332 90.734 314.594 0 202.664 0S0 90.734 0 202.664c0 111.93 90.734 202.668 202.664 202.668 111.93 0 202.668-90.738 202.668-202.668zm-179.094 84.27-85.332-74.668a12.731 12.731 0 0 1-4.375-9.602c0-3.68 1.598-7.184 4.375-9.598l85.332-74.668c5.301-4.652 13.375-4.128 18.028 1.172 4.652 5.305 4.128 13.375-1.172 18.028l-74.348 65.066 74.348 65.066c5.3 4.657 5.824 12.727 1.172 18.028-4.653 5.304-12.727 5.828-18.028 1.176zm0 0" data-original="#000000" />
                                                    </svg>
                                                </div>
                                                <div className="swiper-button-next-custom">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 405.333 405.333">
                                                        <circle cx="202.667" cy="202.667" r="202.667" fill="#fff" transform="matrix(.71 0 0 .71 58.773 58.773)" />
                                                        <path fill="#7492a9" d="M0 202.668c0 111.93 90.738 202.664 202.668 202.664s202.664-90.734 202.664-202.664C405.332 90.738 314.598 0 202.668 0 90.738 0 0 90.738 0 202.668zm179.094-84.27 85.332 74.668a12.731 12.731 0 0 1 4.375 9.602c0 3.68-1.598 7.184-4.375 9.598l-85.332 74.668c-5.301 4.652-13.375 4.128-18.028-1.172-4.652-5.305-4.128-13.375 1.172-18.028l74.348-65.066-74.348-65.066c-5.3-4.657-5.824-12.727-1.172-18.028 4.653-5.304 12.727-5.828 18.028-1.176zm0 0" data-original="#000000" />
                                                    </svg>
                                                </div>
                                            </div>
                                            <Swiper
                                                modules={[Navigation]}
                                                navigation={{
                                                    nextEl: '.swiper-button-next-custom',
                                                    prevEl: '.swiper-button-prev-custom',
                                                }}
                                                spaceBetween={10}
                                                slidesPerView={3}
                                            // onSlideChange={() => console.log('slide change')}
                                            // onSwiper={(swiper) => console.log(swiper)}
                                            >
                                                {balancearray.map((balance, index) =>
                                                    <SwiperSlide key={index}>
                                                        <div className="d_user_leave_balance_listing">
                                                            <div className="d_user_leave_balance_type"
                                                                style={{ backgroundColor: balance.color_code }}>
                                                                {balance.leaveType && (() => {
                                                                    const [firstWord, ...rest] = balance.leaveType.split(' ');
                                                                    return (
                                                                        <>
                                                                            <span>{firstWord}</span>
                                                                            <br />
                                                                            {rest.join(' ')}
                                                                        </>
                                                                    );
                                                                })()}
                                                            </div>
                                                            {/* <div className="d_user_leave_balance_balance"> */}
                                                            <CircularProgressbar value={balance.leaveBalance} maxValue={balance.leaveAllotedCount} text={balance.leaveType}
                                                                styles={buildStyles({
                                                                    // backgroundColor: "transparent",
                                                                    // textColor: "#000",
                                                                    // pathColor: "#ed2024",
                                                                    // trailColor: "transparent",
                                                                    // textSize: "14px"
                                                                })} />
                                                            {/* {balance.leaveBalance}/{balance.leaveAllotedCount} */}
                                                            {/* </div> */}
                                                        </div>
                                                    </SwiperSlide>
                                                )}
                                            </Swiper>
                                            {/* ---- */}
                                        </div>
                                        <div className="new_user_fourth_rightbox">
                                            <div className="new_user_fourth_right_btnbox">
                                                <a href={pageURL_userApplyLeaveForm}>
                                                    <div className="new_user_apply_new_btnbox">
                                                        <div className="new_user_apply_new_leftbox">
                                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="20" height="20" x="0" y="0" viewBox="0 0 520 520">
                                                                <g transform="matrix(1.13,0,0,1.13,-33.799775848388606,-33.800293083190866)">
                                                                    <path d="M239.987 460.841a10 10 0 0 1-7.343-3.213L34.657 243.463A10 10 0 0 1 42 226.675h95.3a10.006 10.006 0 0 1 7.548 3.439l66.168 76.124c7.151-15.286 20.994-40.738 45.286-71.752 35.912-45.85 102.71-113.281 216.994-174.153a10 10 0 0 1 10.85 16.712c-.436.341-44.5 35.041-95.212 98.6-46.672 58.49-108.714 154.13-139.243 277.6a10 10 0 0 1-9.707 7.6z" data-name="6-Check" fill="#ffffff" opacity="1" data-original="#000000"></path>
                                                                </g>
                                                            </svg>
                                                        </div>
                                                        <div className="new_user_apply_new_rightbox">Apply Leave</div>
                                                    </div>
                                                </a>
                                            </div>
                                            {contextRoleID != "5" &&
                                                <div className="new_user_fourth_right_btnbox">
                                                    <a href={pageURL_userTeamLeave}>
                                                        <div className="new_user_apply_new_btnbox">
                                                            <div className="new_user_apply_new_leftbox">
                                                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="20" height="20" x="0" y="0" viewBox="0 0 24 24">
                                                                    <g transform="matrix(1.0999999999999999,0,0,1.0999999999999999,-1.199999940395351,-1.1999999999999957)">
                                                                        <path d="M17.233 15.328a4.773 4.773 0 0 0-4.7-4.078h-1.064a4.773 4.773 0 0 0-4.7 4.078l-.51 3.566a.75.75 0 0 0 .213.636c.2.2 1.427 1.22 5.53 1.22s5.327-1.016 5.53-1.22a.75.75 0 0 0 .213-.636zM7.56 11.8a5.7 5.7 0 0 0-1.78 3.39l-.37 2.56c-2.97-.02-3.87-1.1-4.02-1.32a.739.739 0 0 1-.13-.56l.22-1.24a4.093 4.093 0 0 1 6.08-2.83zM22.74 15.87a.739.739 0 0 1-.13.56c-.15.22-1.05 1.3-4.02 1.32l-.37-2.56a5.7 5.7 0 0 0-1.78-3.39 4.093 4.093 0 0 1 6.08 2.83zM7.73 9.6a2.714 2.714 0 0 1-2.23 1.15A2.75 2.75 0 1 1 7.15 5.8 4.812 4.812 0 0 0 7 7a5.01 5.01 0 0 0 .73 2.6zM21.25 8a2.748 2.748 0 0 1-2.75 2.75 2.714 2.714 0 0 1-2.23-1.15A5.01 5.01 0 0 0 17 7a4.812 4.812 0 0 0-.15-1.2 2.75 2.75 0 0 1 4.4 2.2z" fill="#ffffff" opacity="1" data-original="#000000"></path>
                                                                        <circle cx="12" cy="7" r="3.75" fill="#ffffff" opacity="1" data-original="#000000"></circle>
                                                                    </g>
                                                                </svg>
                                                            </div>
                                                            <div className="new_user_apply_new_rightbox">My Team</div>
                                                        </div>
                                                    </a>
                                                </div>}
                                        </div>
                                    </div>
                                    {/* } */}
                                    <div className="new_user_left_secondmainbox">
                                    </div>
                                    <div className="new_user_left_thirdmainbox">
                                        <div className="nw_user_inner_mainbox">
                                            <div className="nw_user_inner_heading_tabbox">
                                                <div className="heading25">
                                                    About <span>Organization</span>
                                                </div>
                                                <div className="nw_user_inner_tabs">
                                                    <ul>
                                                        <li className={tabSelectedIndex == 0 ? "nw_user_inner_listing_selected" : "nw_user_inner_listing"} key={0}>
                                                            <a onClick={(e) => { setTabSelectedIndex(0), setLoadingCursor(true) }} className={tabSelectedIndex == 0 ? "nw_user_selected" : "new_list_view_heading"}>
                                                                <div className="nw_user_tab_icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="15" height="15" x="0" y="0" viewBox="0 0 512 512">
                                                                        <g>
                                                                            <path className='black_to_white_fill' d="M446.605 124.392 326.608 4.395A15.02 15.02 0 0 0 316 0H106C81.187 0 61 20.187 61 45v422c0 24.813 20.187 45 45 45h300c24.813 0 45-20.187 45-45V135c0-4.09-1.717-7.931-4.395-10.608zM331 51.213 399.787 120H346c-8.271 0-15-6.729-15-15zM406 482H106c-8.271 0-15-6.729-15-15V45c0-8.271 6.729-15 15-15h195v75c0 24.813 20.187 45 45 45h75v317c0 8.271-6.729 15-15 15z" fill="#000000" opacity="1" data-original="#000000"></path>
                                                                            <path className='black_to_white_fill' d="M346 212H166c-8.284 0-15 6.716-15 15s6.716 15 15 15h180c8.284 0 15-6.716 15-15s-6.716-15-15-15zM346 272H166c-8.284 0-15 6.716-15 15s6.716 15 15 15h180c8.284 0 15-6.716 15-15s-6.716-15-15-15zM346 332H166c-8.284 0-15 6.716-15 15s6.716 15 15 15h180c8.284 0 15-6.716 15-15s-6.716-15-15-15zM286 392H166c-8.284 0-15 6.716-15 15s6.716 15 15 15h120c8.284 0 15-6.716 15-15s-6.716-15-15-15z" fill="#000000" opacity="1" data-original="#000000">
                                                                            </path>
                                                                        </g>
                                                                    </svg>
                                                                </div>
                                                                <div className="nw_user_tab_name">
                                                                    Todays Tasks
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li className={tabSelectedIndex == 1 ? "nw_user_inner_listing_selected" : "nw_user_inner_listing"} key={1}>
                                                            <a onClick={(e) => { setTabSelectedIndex(1), setLoadingCursor(true) }} className={tabSelectedIndex == 1 ? "nw_user_selected" : "new_list_view_heading"}>
                                                                <div className="nw_user_tab_icon">
                                                                    <svg width="15" height="15" viewBox="0 0 682.667 682.667">
                                                                        <defs><clipPath id="a" clipPathUnits="userSpaceOnUse"><path fill="red" d="M0 512h512V0H0Z" data-original="#000000" /></clipPath></defs>
                                                                        <g fill="none" className="black_to_white_stoke" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="30" clip-path="url(#a)" transform="matrix(1.33333 0 0 -1.33333 0 682.667)">
                                                                            <path d="M497 376.5H15V104c0-32.516 26.359-58.875 58.875-58.875h364.25C470.641 45.125 497 71.484 497 104zM346.375 376.5h-180.75v44.808c0 25.166 20.401 45.567 45.567 45.567h89.616c25.166 0 45.567-20.401 45.567-45.567Z" data-original="#000000" />
                                                                            <path d="M15 376.5c0-87.23 82.38-160.02 191.97-177.01M305.03 199.49C414.62 216.48 497 289.27 497 376.5" data-original="#000000" />
                                                                            <path d="M305.03 244.78v-49.03c0-27.08-21.95-49.03-49.03-49.03-27.08 0-49.03 21.95-49.03 49.03v49.03Z" data-original="#000000" />
                                                                        </g>
                                                                    </svg>
                                                                </div>
                                                                <div className="nw_user_tab_name">
                                                                    Team Members
                                                                </div>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div className="nw_user_inner_content_box">
                                                {
                                                    tabSelectedIndex == 0 ?
                                                        // Company documents
                                                        <>
                                                            <div className="row">
                                                                <div className="col-lg-12">
                                                                    1
                                                                </div>
                                                            </div>
                                                        </>
                                                        : tabSelectedIndex == 1 ?
                                                            // Official documents
                                                            <>
                                                                <div className="row">
                                                                    <div className="col-lg-12">
                                                                        2
                                                                    </div>
                                                                </div>
                                                            </>
                                                            : <div />
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="new_user_dashbord_rightbox">
                                    {/* {permissionData(permission_m_notification_9) && */}
                                    <div className="new_user_notification_mainbox">
                                        <div className="new_user_notification_headingbox">
                                            <div className="new_user_notification_icon">
                                                <img src="/images/user/notification-icon.svg" alt="Notification Icon" className="img-fluid" />
                                            </div>
                                            <div className="new_user_notification_heading">Notification Corner</div>
                                        </div>
                                        <div className="new_user_notification_listing">
                                            <ul className="user_notification_list">
                                                <li><a href="">Happy Birthday Sahil Khambe<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Celebration  of International Workers Day on 1 May 2025<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque, repudiandae!<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Lorem ipsum dolor sit amet consectetur adipisicing elit.<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt?<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Happy Birthday Sahil Khambe<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Celibration  of International Workers Day on 1 May 2025<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque, repudiandae!<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Lorem ipsum dolor sit amet consectetur adipisicing elit.<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                                <li><a href="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt?<span className='notification_detail_icon'><img src="/images/user/notification-detail-icon.svg" alt="Notification detail" className="img-fluid" /></span></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    {/* } */}
                                    {/* {permissionData(permission_m_holiday_id) && */}
                                    <div className="new_user_holiday_list_mainbox">
                                        <div className="new_user_notification_headingbox">
                                            <div className="new_user_notification_icon">
                                                <img src="/images/user/calender.svg" alt="Calender Icon" className="img-fluid" />
                                            </div>
                                            <div className="new_user_notification_heading"> Holiday List</div>
                                        </div>
                                        <div className="new_user_notification_listing_scroll">
                                            {holidays.map((holiday) => (
                                                <div className="new_user_notification_listing" key={holiday.id}>
                                                    <div className="monthely_holiday_listing" >
                                                        <div className="monthely_holiday_leftbox">
                                                            <div className="monthely_holiday_day">{moment(holiday.date).format("Do")}</div>
                                                            <div className="monthely_holiday_date">{moment(holiday.date).format("MMMM")}</div>
                                                        </div>
                                                        <div className="monthely_holiday_rightbox">
                                                            {holiday.holiday_name}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    {/* } */}
                                    <div className="new_user_meeting_mainbox">
                                        {/* <div className="new_user_notification_headingbox">
                                            <div className="new_user_notification_icon">
                                                <img src="/images/user/video.svg" alt="Calender Icon" className="img-fluid" />
                                            </div>
                                            <div className="new_user_notification_heading">Meeting List</div>
                                        </div> */}
                                        <div className="new_user_calender_listing">
                                            <iframe src="https://calendar.google.com/calendar/embed?height=200&wkst=1&ctz=Asia%2FKolkata&showPrint=0&src=cml0aWthLnNAZXZvbml4LmNv&src=ZW4uaW5kaWFuI2hvbGlkYXlAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&color=%23039BE5&color=%230B8043" style={{ borderWidth: "0", width: "400", height: "200", border: "0" }}></iframe>
                                        </div>
                                    </div>
                                    {/* <div className="new_user_meeting_mainbox">
                                        <div className="new_user_meeting_btn_mainbox">
                                            <div className="new_user_meeting_btn_leftbox">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 512.237 512.237">
                                                    <g fill="#7492a9"><path d="M55.224 265.937h38.882c7.302 0 13.242-5.94 13.242-13.243v-38.881c0-7.302-5.94-13.243-13.242-13.243H55.224c-7.302 0-13.242 5.94-13.242 13.243v38.881c-.001 7.303 5.94 13.243 13.242 13.243zm1.757-50.367h35.366v35.367H56.981V215.57zm88.968 50.367h38.881c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881c0 7.303 5.94 13.243 13.243 13.243zm1.757-50.367h35.367v35.367h-35.367V215.57zm88.968 50.367h38.881c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881c0 7.303 5.94 13.243 13.243 13.243zm1.757-50.367h35.367v35.367h-35.367V215.57zm127.848 50.367c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881c0 7.302 5.94 13.243 13.243 13.243h38.881zm-37.124-50.367h35.367v35.367h-35.367V215.57zm127.85-15h-38.882c-7.302 0-13.242 5.94-13.242 13.243v38.881c0 7.302 5.94 13.243 13.242 13.243h38.882c7.302 0 13.242-5.94 13.242-13.243v-38.881c0-7.302-5.94-13.243-13.242-13.243zm-1.758 50.367h-35.366V215.57h35.366v35.367zm-413.266 85.32c0 7.302 5.94 13.243 13.242 13.243h38.882c7.302 0 13.242-5.94 13.242-13.243v-38.881c0-7.302-5.94-13.243-13.242-13.243H55.224c-7.302 0-13.242 5.94-13.242 13.243v38.881zm15-37.124h35.366V334.5H56.981v-35.367zm75.725 37.124c0 7.302 5.94 13.243 13.243 13.243h38.881c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881zm15-37.124h35.367V334.5h-35.367v-35.367zm75.725 37.124c0 7.302 5.94 13.243 13.243 13.243h38.881c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881zm15-37.124h35.367V334.5h-35.367v-35.367zM41.981 419.819c0 7.302 5.94 13.243 13.242 13.243h38.882c7.302 0 13.242-5.94 13.242-13.243v-38.881c0-7.302-5.94-13.243-13.242-13.243H55.224c-7.302 0-13.242 5.94-13.242 13.243v38.881zm15-37.124h35.366v35.367H56.981v-35.367zm75.725 37.124c0 7.302 5.94 13.243 13.243 13.243h38.881c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881zm15-37.124h35.367v35.367h-35.367v-35.367zm75.725 37.124c0 7.302 5.94 13.243 13.243 13.243h38.881c7.303 0 13.243-5.94 13.243-13.243v-38.881c0-7.302-5.94-13.243-13.243-13.243h-38.881c-7.303 0-13.243 5.94-13.243 13.243v38.881zm15-37.124h35.367v35.367h-35.367v-35.367zm153.771 56.549c41.352 0 75.822-30.972 80.184-72.043a7.5 7.5 0 0 0-6.666-8.25 7.497 7.497 0 0 0-8.25 6.666c-3.549 33.423-31.607 58.627-65.268 58.627-36.197 0-65.646-29.449-65.646-65.646s29.449-65.646 65.646-65.646a65.506 65.506 0 0 1 21.052 3.47 7.501 7.501 0 0 0 4.811-14.208 80.495 80.495 0 0 0-25.862-4.262c-44.469 0-80.646 36.178-80.646 80.646s36.176 80.646 80.645 80.646z" data-original="#000000" /><path d="m447.996 289.964-62.718 58.354-7.717-7.669c-2.162-2.149-5.016-3.367-8.079-3.316a11.339 11.339 0 0 0-8.058 3.368l-15.634 15.733a11.335 11.335 0 0 0-3.316 8.079 11.337 11.337 0 0 0 3.368 8.058l23.063 22.919a22.363 22.363 0 0 0 15.86 6.539c5.705 0 11.147-2.14 15.325-6.027l78.558-73.091c4.605-4.286 4.866-11.519.581-16.126l-15.108-16.238c-4.283-4.607-11.517-4.87-16.125-.583zm-58.121 95.054a7.48 7.48 0 0 1-5.108 2.009 7.455 7.455 0 0 1-5.288-2.18l-20.517-20.389 10.573-10.64 10.285 10.222a7.5 7.5 0 0 0 10.396.171l65.369-60.821 10.218 10.982-75.928 70.646z" data-original="#000000" />
                                                        <path d="M471.044 75.817h-45.98V58.19c0-10.64-8.656-19.296-19.296-19.296h-6.806c-10.641 0-19.297 8.656-19.297 19.296v17.626H132.572V58.19c0-10.64-8.656-19.296-19.296-19.296h-6.806c-10.641 0-19.297 8.656-19.297 19.296v17.626h-45.98C18.479 75.817 0 94.296 0 117.01v244.844c0 4.142 3.357 7.5 7.5 7.5s7.5-3.358 7.5-7.5V174.621h78.892c4.143 0 7.5-3.358 7.5-7.5s-3.357-7.5-7.5-7.5H15V117.01c0-14.443 11.75-26.193 26.193-26.193h45.98v17.626c0 10.64 8.656 19.296 19.297 19.296h6.806c10.64 0 19.296-8.656 19.296-19.296V90.817h247.093v17.626c0 10.64 8.656 19.296 19.297 19.296h6.806c10.64 0 19.296-8.656 19.296-19.296V90.817h45.98c14.443 0 26.193 11.75 26.193 26.193v42.611H125.854c-4.143 0-7.5 3.358-7.5 7.5s3.357 7.5 7.5 7.5h371.383v257.53c0 14.443-11.75 26.193-26.193 26.193H41.193C26.75 458.343 15 446.593 15 432.15v-38.334c0-4.142-3.357-7.5-7.5-7.5s-7.5 3.358-7.5 7.5v38.334c0 22.714 18.479 41.193 41.193 41.193h429.851c22.714 0 41.193-18.479 41.193-41.193V117.01c0-22.714-18.479-41.193-41.193-41.193zm-353.472 32.626a4.3 4.3 0 0 1-4.296 4.296h-6.806a4.301 4.301 0 0 1-4.297-4.296V58.19a4.301 4.301 0 0 1 4.297-4.296h6.806a4.3 4.3 0 0 1 4.296 4.296v50.253zm292.491 0a4.3 4.3 0 0 1-4.296 4.296h-6.806a4.301 4.301 0 0 1-4.297-4.296V58.19a4.301 4.301 0 0 1 4.297-4.296h6.806a4.3 4.3 0 0 1 4.296 4.296v50.253z" data-original="#000000" /></g>
                                                </svg>
                                            </div>
                                            <div className="new_user_meeting_btn_rightbox">
                                                MEETINGS
                                            </div>
                                        </div>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            }
            />
            <Footer />
        </div>
    )
}
export default Dashboard