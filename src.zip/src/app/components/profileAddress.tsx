// 'use client'

// import React, { useEffect, useState } from 'react'
// import supabase from '@/app/api/supabaseConfig/supabase';
// import { useRouter } from 'next/navigation';
// import { error } from 'console';
// import { Address, AddressModel, CustomerAddress, EmergencyContact, LeapRelations } from '../models/employeeDetailsModel';
// import LoadingDialog from '@/app/components/PageLoader';
// import { useGlobalContext } from '../contextProviders/loggedInGlobalContext';

// export const UserAddress = () => {
//     // const [userData, setUserData] = useState<Address>();
//     const router = useRouter();
    
//     const[isLoading,setLoading]=useState(false)
//     const [emergencyContactRelation, setEmergencyRelation] = useState<LeapRelations[]>([]);
//     const [currentAdd, setcurrent] = useState<CustomerAddress>({
//         id: 0,
//         client_id: 0,
//         branch_id: 0,
//         customer_id: 0,
//         address_line1: '',
//         address_line2: '',
//         city: '',
//         state: '',
//         postal_code: '',
//         country: '',
//         latitude: '',
//         longitude: '',
//         is_primary: false,
//         created_at: '',
//         updated_at: '',
//         address_type: '',
//     });
//     const [permenantAdd, setpermenant] = useState<CustomerAddress>({
//         id: 0,
//         client_id: 0,
//         branch_id: 0,
//         customer_id: 0,
//         address_line1: '',
//         address_line2: '',
//         city: '',
//         state: '',
//         postal_code: '',
//         country: '',
//         latitude: '',
//         longitude: '',
//         is_primary: false,
//         created_at: '',
//         updated_at: '',
//         address_type: '',
//     });
//     const [emergencyContact, setEmergencyContact] = useState<EmergencyContact>({
//         emergency_contact: '',
//         contact_name: '',
//         relation: '',
//         leap_relations: {
//             id: 0,
//             relation_type: '',
//         }
//     })

//     useEffect(() => {
//         const fetchData = async () => {

//             const relationsType = await getRelations();
//             setEmergencyRelation(relationsType);

//             try {
//                 const formData = new FormData();
//                 formData.append("client_id", contextClientID);
//                 formData.append("customer_id", contextSelectedCustId);


//                 const res = await fetch("/api/users/getProfile/getEmployeeAddress", {
//                     method: "POST",
//                     body: formData,
//                 });
//                 console.log(res);

//                 const response = await res.json();

//                 const user = response.data;


//                 for (let i = 0; i < user.customerAddress.length; i++) {
//                     console.log("Inside for loop", user.customerAddress[i].address_type);

//                     if (response.data.customerAddress[i].address_type == "current") {
//                         console.log("Inside if condition ", user.customerAddress[i]);

//                         setcurrent(response.data.customerAddress[i]);
//                     } else {
//                         console.log("Inside else condition ", user.customerAddress[i]);
//                         setpermenant(response.data.customerAddress[i]);
//                     }
//                 }
//                 // setUserData(user);
//                 setEmergencyContact(user.emergencyContact[0])


//             } catch (error) {
//                 console.error("Error fetching user data:", error);
//             }
//         }
//         fetchData();
//     }, []);

//     const formData = new FormData();

 

//     // const handleInputChange = (e: any) => {
//     //     const { name, value, type, files } = e.target;
//     //     console.log("Form values updated:", userData);
//     //     // setUserData((prev) => ({ ...prev, [name]: value }));
//     // };
//     const {contextClientID,contextRoleID,contextSelectedCustId}=useGlobalContext();

//     const handleSubmit = async (e: React.FormEvent) => {
//         setLoading(true);
//         {/* AddressDetails details 1 */ }
//         e.preventDefault();
//         console.log("Emeekhbhdhfsdhaba ada-d---------",emergencyContact.emergency_contact);
        
//         formData.append("customer_id", currentAdd.customer_id+'');
//         formData.append("role_id", contextRoleID);
//         formData.append("current_id", currentAdd.id+'');
//         formData.append("c_address_line1", currentAdd.address_line1);
//         formData.append("c_address_line2", currentAdd.address_line2);
//         formData.append("c_city", currentAdd.city);
//         formData.append("c_state", currentAdd.state);
//         formData.append("c_postal_code", currentAdd.postal_code);
//         formData.append("c_country", currentAdd.country);

//         formData.append("permenant_id", permenantAdd.id+'');
//         formData.append("p_address_line1", permenantAdd.address_line1);
//         formData.append("p_address_line2", permenantAdd.address_line2);
//         formData.append("p_city", permenantAdd.city);
//         formData.append("p_state", permenantAdd.state);
//         formData.append("p_postal_code", permenantAdd.postal_code);
//         formData.append("p_country", permenantAdd.country);

//         formData.append("emergency_contact", emergencyContact.emergency_contact+'');
//         formData.append("contact_name", emergencyContact.contact_name);
//         formData.append("relation", emergencyContact.relation);
//         try{
           
//             const res = await fetch("/api/users/updateEmployee/updateEmpAddress", {
//                 method: "POST",
//                 body: formData,
//             });
//             const response=await res.json();
//             if(res.ok){
//                 setLoading(false);
//                 alert(response.message);
//             }else{
//                 setLoading(false)
//                 alert(response.message);
//             }
//             }catch(e){
//                 setLoading(false)
//                 alert(e);
//             }

//     }

//     return (
//         <>
//             <form onSubmit={handleSubmit}>
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12 mb-5">

//                             <div className="grey_box">
//                                 <div className="row">
//                                     <div className="col-lg-12">
//                                         <div className="add_form_inner">
//                                             <div className="row">
//                                                 <div className="col-lg-12 mb-4 inner_heading25">
//                                                     Current Address Details:
//                                                 </div>
//                                             </div>
//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Line 1:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="address_line1" value={currentAdd.address_line1|| ""}  name="address_line1" onChange={(e) => setcurrent((prev) => ({ ...prev, ["address_line1"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" > Line 2:</label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="address_line2" value={currentAdd.address_line2|| ""} name="address_line2" onChange={(e) => setcurrent((prev) => ({ ...prev, ["address_line2"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >City:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="city" value={currentAdd.city|| ""} name="city" onChange={(e) => setcurrent((prev) => ({ ...prev, ["city"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >State: </label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="state" value={currentAdd.state|| ""} name="state" onChange={(e) => setcurrent((prev) => ({ ...prev, ["state"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Postal code:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="postal_code" value={currentAdd.postal_code|| ""} name="postal_code" onChange={(e) => setcurrent((prev) => ({ ...prev, ["postal_code"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Country:</label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="country" value={currentAdd.country|| ""} name="country" onChange={(e) => setcurrent((prev) => ({ ...prev, ["country"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>&nbsp;
//                         </div>
//                     </div>
//                 </div>
//                 {/* AddressDetails details 2 */}

//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12 mb-5">
//                             <div className="grey_box">
//                                 <div className="row">
//                                     <div className="col-lg-12">
//                                         <div className="add_form_inner">
//                                             <div className="row">
//                                                 <div className="col-lg-12 mb-4 inner_heading25">
//                                                     Permanent Address Details:
//                                                 </div>
//                                             </div>

//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Line 1:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="address_line1" value={permenantAdd.address_line1|| ""} name="address_line1" onChange={(e) => setpermenant((prev) => ({ ...prev, ["address_line1"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Line 2:</label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="address_line2" value={permenantAdd.address_line2|| ""} name="address_line2" onChange={(e) => setpermenant((prev) => ({ ...prev, ["address_line2"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >City:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="city" value={permenantAdd.city|| ""} name="city" onChange={(e) => setpermenant((prev) => ({ ...prev, ["city"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >State: </label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="state" value={permenantAdd.state|| ""} name="state" onChange={(e) => setpermenant((prev) => ({ ...prev, ["state"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Postal code:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="postal_code" value={permenantAdd.postal_code|| ""} name="postal_code" onChange={(e) => setpermenant((prev) => ({ ...prev, ["postal_code"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Country:</label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="country" value={permenantAdd.country|| ""} name="country" onChange={(e) => setpermenant((prev) => ({ ...prev, ["country"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>&nbsp;

//                         </div>
//                     </div>
//                 </div>


//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12 mb-5">
//                             <div className="grey_box">
//                                 <div className="row">
//                                     <div className="col-lg-12">
//                                         <div className="add_form_inner">
//                                             <div className="row">
//                                                 <div className="col-lg-12 mb-4 inner_heading25">
//                                                     Emergency Contact details:
//                                                 </div>
//                                             </div>

//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Emergency contact:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="emergency_contact" value={emergencyContact.emergency_contact|| ""} name="emergency_contact" onChange={(e) => setEmergencyContact((prev) => ({ ...prev, ["emergency_contact"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Contact person name</label>
//                                                     </div>
//                                                 </div>

//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <input type="text" className="form-control" id="contact_name" value={emergencyContact.contact_name|| ""} name="contact_name" onChange={(e) => setEmergencyContact((prev) => ({ ...prev, ["contact_name"]: e.target.value }))} />
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                             <div className="row" style={{ alignItems: "center" }}>
//                                                 <div className="col-md-2">
//                                                     <div className="form_box mb-3">
//                                                         <label htmlFor="exampleFormControlInput1" className="form-label" >Relation:  </label>
//                                                     </div>
//                                                 </div>
//                                                 <div className="col-md-4">
//                                                     <div className="form_box mb-3">
//                                                         <select id="relation" name="relation" onChange={(e) => setEmergencyContact((prev) => ({ ...prev, ["relation"]: e.target.value }))}>
//                                                             <option value={emergencyContact.leap_relations?.relation_type|| ""}>{emergencyContact?.leap_relations?.relation_type || ""}</option>
//                                                             {emergencyContactRelation.map((relationsType, index) => (
//                                                                 <option value={relationsType.id} key={relationsType.id}>{relationsType.relation_type}</option>
//                                                             ))}
//                                                         </select>
//                                                     </div>
//                                                 </div>

//                                             </div>

//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>&nbsp;
//                             <div className="row">
//                                 <div className="col-lg-12" style={{ textAlign: "right" }}><input type='submit' value="Update" className={`red_button ${isLoading}:"loading":""`} onClick={handleSubmit} /></div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </form>
//         </>
//     )
// }


// async function getRelations() {

//     let query = supabase
//         .from('leap_relations')
//         .select();

//     const { data, error } = await query;
//     if (error) {
//         console.log(error);

//         return [];
//     } else {


//         return data;
//     }
// }



////////////// ritika code merge 




'use client'

import React, { useEffect, useState } from 'react'
import supabase from '@/app/api/supabaseConfig/supabase';
import { useRouter } from 'next/navigation';
import { error } from 'console';
import { Address, AddressModel, CustomerAddress, EmergencyContact, EmergencyContactNew, LeapRelations } from '../models/employeeDetailsModel';
import LoadingDialog from '@/app/components/PageLoader';
import { useGlobalContext } from '../contextProviders/loggedInGlobalContext';
import { apifailedWithException } from '../pro_utils/stringConstants';
import ShowAlertMessage from './alert';

export const UserAddress = () => {
    // const [userData, setUserData] = useState<Address>();
    const router = useRouter();
        const [isBothAddressSame, setBothAddressSame] = useState(false);
    
    
    const[isLoading,setLoading]=useState(false)
    const [showAlert, setShowAlert] = useState(false);
    const [alertForSuccess, setAlertForSuccess] = useState(0);
    const [alertTitle, setAlertTitle] = useState('');
    const [alertStartContent, setAlertStartContent] = useState('');
    const [alertMidContent, setAlertMidContent] = useState('');
    const [alertEndContent, setAlertEndContent] = useState('');
    const [alertValue1, setAlertValue1] = useState('');
    const [alertvalue2, setAlertValue2] = useState('');
    const [emergencyContactRelation, setEmergencyRelation] = useState<LeapRelations[]>([]);
    const [currentAdd, setcurrent] = useState<CustomerAddress>({
        id: 0,
        client_id: 0,
        branch_id: 0,
        customer_id: 0,
        address_line1: '',
        address_line2: '',
        city: '',
        state: '',
        postal_code: '',
        country: '',
        latitude: '',
        longitude: '',
        is_primary: false,
        created_at: '',
        updated_at: '',
        address_type: '',
    });
    const [permenantAdd, setpermenant] = useState<CustomerAddress>({
        id: 0,
        client_id: 0,
        branch_id: 0,
        customer_id: 0,
        address_line1: '',
        address_line2: '',
        city: '',
        state: '',
        postal_code: '',
        country: '',
        latitude: '',
        longitude: '',
        is_primary: false,
        created_at: '',
        updated_at: '',
        address_type: '',
    });
    const [emergencyContact, setEmergencyContact] = useState<EmergencyContactNew[]>([{
        id:0,
        emergency_contact: '',
        contact_name: '',
        
        relation: {
            id: 0,
            relation_type: '',
        }
    }])
    const [addressformErrors, setAddressFormErrors] = useState<Partial<CustomerAddress>>({});
    const [peraddressFormErrors, setPerAddressFormErrors] = useState<Partial<CustomerAddress>>({});
    const [emergencyFieldErrors, setEmergencyFieldErrors] = useState<Partial<EmergencyContactNew>>({});
    

    useEffect(() => {
       
        fetchData();
    }, []);

     const fetchData = async () => {
            const formData = new FormData();
            const relationsType = await getRelations();
            setEmergencyRelation(relationsType);

            try {
                const formData = new FormData();
                formData.append("client_id", contextClientID);
                formData.append("customer_id", contextSelectedCustId);


                const res = await fetch("/api/users/getProfile/getEmployeeAddress", {
                    method: "POST",
                    body: JSON.stringify({
                        "client_id":contextClientID,
                        "customer_id":contextSelectedCustId
                    }),
                });
                console.log(res);

                const response = await res.json();

                const user = response.data;


                for (let i = 0; i < user.customerAddress.length; i++) {
                    console.log("Inside for loop", user.customerAddress[i].address_type);

                    if (response.data.customerAddress[i].address_type == "current") {
                        console.log("Inside if condition ", user.customerAddress[i]);

                        setcurrent(response.data.customerAddress[i]);
                    } else {
                        console.log("Inside else condition ", user.customerAddress[i]);
                        setpermenant(response.data.customerAddress[i]);
                    }
                }
                // setUserData(user);
                if(user.emergencyContact.length>0){
                    
                setEmergencyContact(user.emergencyContact)
                }else{
                    const emer:EmergencyContactNew[]=[{
                            id:0,
                            emergency_contact: '',
                            contact_name: '',
                            
                            relation: {
                                id: 0,
                                relation_type: '',
                            }
                        }]
                   setEmergencyContact(emer)     
                }


            } catch (error) {
                console.error("Error fetching user data:", error);
            }
        }

 const sameAddress = (setSame: boolean) => {

        if (setSame) {
            setpermenant((prev) => ({ ...prev, ["address_line1"]:  currentAdd.address_line1}))
            setpermenant((prev) => ({ ...prev, ["address_line2"]:  currentAdd.address_line2}))
            setpermenant((prev) => ({ ...prev, ["city"]:  currentAdd.city}))
            setpermenant((prev) => ({ ...prev, ["state"]:  currentAdd.state}))
            setpermenant((prev) => ({ ...prev, ["postal_code"]:  currentAdd.postal_code}))
            setpermenant((prev) => ({ ...prev, ["country"]:  currentAdd.country}))
            setpermenant((prev) => ({ ...prev, ["latitude"]:  currentAdd.latitude}))
            setpermenant((prev) => ({ ...prev, ["longitude"]:  currentAdd.longitude}))
        }
    }
    // const handleInputChange = (e: any) => {
    //     const { name, value, type, files } = e.target;
    //     console.log("Form values updated:", userData);
    //     // setUserData((prev) => ({ ...prev, [name]: value }));
    // };
    const {contextClientID,contextRoleID,contextSelectedCustId}=useGlobalContext();

    const validate = () => {
        const currAddErrors: Partial<CustomerAddress> = {};
        const perAddErrors: Partial<CustomerAddress> = {};
        const emerFieldErrors: Partial<EmergencyContactNew> = {};
        if (!currentAdd.address_line1) currAddErrors.address_line1 = "required";
        if (!currentAdd.address_line2) currAddErrors.address_line2 = "required";
        if (!currentAdd.city) currAddErrors.city = "required";
        if (!currentAdd.state) currAddErrors.state = "required";
        if (!currentAdd.postal_code) currAddErrors.postal_code = "required";
        if (!currentAdd.country) currAddErrors.country = "required";
        
        if (!permenantAdd.address_line1) perAddErrors.address_line1 = "required";
        if (!permenantAdd.address_line2) perAddErrors.address_line2 = "required";
        if (!permenantAdd.city) perAddErrors.city = "required";
        if (!permenantAdd.state) perAddErrors.state = "required";
        if (!permenantAdd.postal_code) perAddErrors.postal_code = "required";
        if (!permenantAdd.country) perAddErrors.country = "required";

        if (!emergencyContact[0].contact_name) emerFieldErrors.contact_name = "required";
        if (!emergencyContact[0].emergency_contact) emerFieldErrors.emergency_contact = "required";
        if (!emergencyContact[0].relation || emergencyContact[0].relation.id==0) emerFieldErrors.relation = { id: 0, relation_type: "required" };

        setAddressFormErrors(currAddErrors);
        setPerAddressFormErrors(perAddErrors);
        setEmergencyFieldErrors(emerFieldErrors);

        const validationSuccess =
            Object.keys(currAddErrors).length === 0 &&
            Object.keys(perAddErrors).length === 0 &&
            Object.keys(emerFieldErrors).length === 0;

        return validationSuccess;


    }
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        if(!validate()) return;
        setLoading(true);
        {/* AddressDetails details 1 */ }

        const formData = new FormData();
        formData.append("customer_id", currentAdd.customer_id+'');
        formData.append("role_id", contextRoleID);
        formData.append("client_id", contextClientID);
        formData.append("current_id", currentAdd.id+'');
        formData.append("c_address_line1", currentAdd.address_line1);
        formData.append("c_address_line2", currentAdd.address_line2);
        formData.append("c_city", currentAdd.city);
        formData.append("c_state", currentAdd.state);
        formData.append("c_postal_code", currentAdd.postal_code);
        formData.append("c_country", currentAdd.country);

        formData.append("permenant_id", permenantAdd.id+'');
        formData.append("p_address_line1", permenantAdd.address_line1);
        formData.append("p_address_line2", permenantAdd.address_line2);
        formData.append("p_city", permenantAdd.city);
        formData.append("p_state", permenantAdd.state);
        formData.append("p_postal_code", permenantAdd.postal_code);
        formData.append("p_country", permenantAdd.country);

        formData.append("emergency_contact_array", JSON.stringify(emergencyContact));
        // formData.append("contact_name", emergencyContact.contact_name);
        // formData.append("relation", emergencyContact.relation.id+"");
        try{
           
            const res = await fetch("/api/users/updateEmployee/updateEmpAddress", {
                method: "POST",
                body: formData,
            });
            const response=await res.json();
            if(res.ok && response.status==1){
                setLoading(false);
                
                setShowAlert(true);
                setAlertTitle("Success")
                setAlertStartContent("Data updated successfully");
                setAlertForSuccess(1)
            }else{
                setLoading(false)
                
                setShowAlert(true);
                setAlertTitle("Error")
                setAlertStartContent(response.message);
                setAlertForSuccess(2)
            }
            }catch(e){
                setLoading(false)
                setShowAlert(true);
                setAlertTitle("Exception")
                setAlertStartContent(apifailedWithException);
                setAlertForSuccess(2)
            }

    }
    function isReadonly(){
        if(contextRoleID == "2" || contextRoleID == "3"){
            return false;
        }else{
            return true;
        }
    }
    return (
        <>
        <LoadingDialog isLoading={isLoading} />
            {showAlert && <ShowAlertMessage title={alertTitle} startContent={alertStartContent} midContent={alertMidContent && alertMidContent.length > 0 ? alertMidContent : ""} endContent={alertEndContent} value1={alertValue1} value2={alertvalue2} onOkClicked={function (): void {
                setShowAlert(false)
                if (alertForSuccess == 1) {
                    fetchData();
                }
            }} onCloseClicked={function (): void {
                setShowAlert(false)
            }} showCloseButton={false} imageURL={''} successFailure={alertForSuccess} />}
            <form onSubmit={handleSubmit}>
                <div>
                    <div className="row">
                        <div className="col-lg-12 mb-2">

                            <div className="grey_box">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="add_form_inner">
                                            <div className="row">
                                                <div className="col-lg-12 mb-4 inner_heading25">
                                                    Current Address Details:
                                                </div>
                                            </div>
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Line 1<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="address_line1" readOnly={isReadonly()} value={currentAdd.address_line1|| ""}  name="address_line1" 
                                                        onChange={(e) => 
                                                            {setcurrent((prev) => ({ ...prev, ["address_line1"]: e.target.value })); 
                                                            if(isBothAddressSame){            
                                                                setpermenant((prev) => ({ ...prev, ["address_line1"]:  e.target.value}))
                                                                }}} />
                                                        {addressformErrors.address_line1 && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Line 2<span className='req_text'>*</span> :</label>
                                                    </div>
                                                </div>

                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="address_line2" readOnly={isReadonly()} value={currentAdd.address_line2|| ""} name="address_line2" 
                                                        onChange={(e) => {
                                                        setcurrent((prev) => ({ ...prev, ["address_line2"]: e.target.value }));
                                                    if(isBothAddressSame){            
                                                                setpermenant((prev) => ({ ...prev, ["address_line2"]:  e.target.value}))
                                                                }}}  />
                                                        {addressformErrors.address_line2 && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >City<span className='req_text'>*</span> :</label>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" 
                                                        onKeyPress={(e) => {
                                                                                if (!/^[A-Za-z\s]$/.test(e.key)) {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                        className="form-control" id="city" readOnly={isReadonly()} value={currentAdd.city|| ""} name="city" 
                                                        onChange={(e) => {
                                                            setcurrent((prev) => ({ ...prev, ["city"]: e.target.value }));
                                                            if(isBothAddressSame){            
                                                                setpermenant((prev) => ({ ...prev, ["city"]:  e.target.value}))
                                                                }}}  />
                                                        {addressformErrors.city && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >State<span className='req_text'>*</span> : </label>
                                                        
                                                    </div>
                                                </div>

                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" 
                                                        onKeyPress={(e) => {
                                                                                if (!/^[A-Za-z\s]$/.test(e.key)) {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                        className="form-control" id="state" readOnly={isReadonly()} value={currentAdd.state|| ""} name="state" 
                                                        onChange={(e) => {
                                                            setcurrent((prev) => ({ ...prev, ["state"]: e.target.value }));
                                                            if(isBothAddressSame){            
                                                                setpermenant((prev) => ({ ...prev, ["state"]:  e.target.value}));
                                                                }}}  />
                                                        {addressformErrors.state && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-2">
                                                    <div className="form_box">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Postal code<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="form_box">
                                                        <input type="text" className="form-control" id="postal_code" maxLength={10} readOnly={isReadonly()} value={currentAdd.postal_code|| ""} name="postal_code" 
                                                        onChange={(e) => {
                                                        setcurrent((prev) => ({ ...prev, ["postal_code"]: e.target.value }))
                                                        if(isBothAddressSame){            
                                                                setpermenant((prev) => ({ ...prev, ["postal_code"]:  e.target.value}))
                                                                }}}  />
                                                        {addressformErrors.postal_code && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                    <div className="form_box">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Country<span className='req_text'>*</span> :</label>
                                                    </div>
                                                </div>

                                                <div className="col-md-4">
                                                    <div className="form_box">
                                                        <input type="text" className="form-control" id="country" 
                                                        onKeyPress={(e) => {
                                                                                if (!/^[A-Za-z\s]$/.test(e.key)) {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                        readOnly={isReadonly()} value={currentAdd.country|| ""} name="country" 
                                                        onChange={(e) => {
                                                            setcurrent((prev) => ({ ...prev, ["country"]: e.target.value }));
                                                            if(isBothAddressSame){            
                                                                setpermenant((prev) => ({ ...prev, ["country"]:  e.target.value}))
                                                                }}}  />
                                                        {addressformErrors.country && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>&nbsp;
                        </div>
                    </div>
                </div>
                {/* AddressDetails details 2 */}

                <div>
                    <div className="row">
                        <div className="col-lg-12 mb-2">
                            <div className="grey_box">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="add_form_inner">
                                            <div className="row">
                                                <div className="col-lg-12 mb-4 inner_heading25">
                                                    Permanent Address Details:
                                                    <div className='sameadd_box'>
                                                            <input type="checkbox" id='sameadd' name='sameadd' />
                                                            <label htmlFor='sameadd' onClick={(e) => {
                                                                isBothAddressSame ? setBothAddressSame(false) : setBothAddressSame(true);
                                                                sameAddress(isBothAddressSame ? false : true)
                                                            }}>Copy Current Address</label>
                                                    </div>
                                                </div>
                                                
                                            </div>

                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Line 1<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="address_line1" readOnly={isReadonly()} value={permenantAdd.address_line1|| ""} name="address_line1" 
                                                        onChange={(e) => {
                                                            setpermenant((prev) => ({ ...prev, ["address_line1"]: e.target.value }))
                                                            if(isBothAddressSame){            
                                                                setcurrent((prev) => ({ ...prev, ["address_line1"]:  e.target.value}))
                                                                }}}  />
                                                        {peraddressFormErrors.address_line1 && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Line 2<span className='req_text'>*</span> :</label>
                                                    </div>
                                                </div>

                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="address_line2" readOnly={isReadonly()} value={permenantAdd.address_line2|| ""} name="address_line2" 
                                                        onChange={(e) => {setpermenant((prev) => ({ ...prev, ["address_line2"]: e.target.value }));
                                                        if(isBothAddressSame){            
                                                                setcurrent((prev) => ({ ...prev, ["address_line2"]:  e.target.value}))
                                                                }}} />
                                                        {peraddressFormErrors.address_line2 && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >City<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="city" 
                                                        onKeyPress={(e) => {
                                                                                if (!/^[A-Za-z\s]$/.test(e.key)) {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                        readOnly={isReadonly()} value={permenantAdd.city|| ""} name="city" 
                                                        onChange={(e) => {
                                                            setpermenant((prev) => ({ ...prev, ["city"]: e.target.value }))
                                                            if(isBothAddressSame){            
                                                                setcurrent((prev) => ({ ...prev, ["city"]:  e.target.value}))
                                                                }}} />
                                                        {peraddressFormErrors.city && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >State<span className='req_text'>*</span> : </label>
                                                    </div>
                                                </div>

                                                <div className="col-md-4">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="state"  
                                                        onKeyPress={(e) => {
                                                                                if (!/^[A-Za-z\s]$/.test(e.key)) {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                        readOnly={isReadonly()} value={permenantAdd.state|| ""} name="state" 
                                                        onChange={(e) => {
                                                            setpermenant((prev) => ({ ...prev, ["state"]: e.target.value }))
                                                            if(isBothAddressSame){            
                                                                setcurrent((prev) => ({ ...prev, ["state"]:  e.target.value}))
                                                                }}} />
                                                        {peraddressFormErrors.state && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-2">
                                                    <div className="form_box">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Postal code<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="form_box">
                                                        <input type="text" className="form-control" id="postal_code" maxLength={10} readOnly={isReadonly()} value={permenantAdd.postal_code|| ""} name="postal_code" 
                                                        onChange={(e) => {
                                                            setpermenant((prev) => ({ ...prev, ["postal_code"]: e.target.value }))
                                                            if(isBothAddressSame){            
                                                                setcurrent((prev) => ({ ...prev, ["postal_code"]:  e.target.value}))
                                                                }}} />
                                                        {peraddressFormErrors.postal_code && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                    <div className="form_box">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Country<span className='req_text'>*</span> :</label>
                                                        
                                                    </div>
                                                </div>

                                                <div className="col-md-4">
                                                    <div className="form_box">
                                                        <input type="text" className="form-control" 
                                                        onKeyPress={(e) => {
                                                                                if (!/^[A-Za-z\s]$/.test(e.key)) {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                        id="country" readOnly={isReadonly()} value={permenantAdd.country|| ""} name="country" 
                                                        onChange={(e) => {
                                                            setpermenant((prev) => ({ ...prev, ["country"]: e.target.value }))
                                                            if(isBothAddressSame){            
                                                                setcurrent((prev) => ({ ...prev, ["country"]:  e.target.value}))
                                                                }}} />
                                                        {peraddressFormErrors.country && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>&nbsp;

                        </div>
                    </div>
                </div>


                <div>
                    <div className="row">
                        <div className="col-lg-12 mb-5">
                            <div className="grey_box mb-3">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="add_form_inner">
                                            <div className="row">
                                                <div className="col-lg-12 mb-4 inner_heading25">
                                                    Emergency Contact details:
                                                </div>
                                            </div>
                                            {emergencyContact  && emergencyContact.map((emergencyContactItem,index) => 
                                            <div className='mt-3' key={index}>                 
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-3">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Emergency contact<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="emergency_contact" maxLength={12} 
                                                        onKeyDown={(e) => {
                                                                if (!/^[0-9]$/.test(e.key) && // allow only digits
                                                                    e.key !== "Backspace" &&
                                                                    e.key !== "Delete" &&
                                                                    e.key !== "ArrowLeft" && // allow navigation
                                                                    e.key !== "ArrowRight" &&
                                                                    e.key !== "Tab") {
                                                                    e.preventDefault();
                                                                }
                                                            }}
                                                        readOnly={isReadonly()} value={emergencyContactItem?.emergency_contact|| ""} name="emergency_contact" 
                                                        onChange={(e) => setEmergencyContact((prev) => {
                                                                    const updated = [...prev]; // copy array
                                                                    updated[index] = {
                                                                    ...updated[index],
                                                                    emergency_contact: e.target.value, // update specific field
                                                                    };
                                                                    return updated;
                                                                })} />
                                                        {emergencyFieldErrors.emergency_contact && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}

                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form_box mb-3">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Contact person name<span className='req_text'>*</span> :</label>
                                                        
                                                    </div>
                                                </div>

                                                <div className="col-md-3">
                                                    <div className="form_box mb-3">
                                                        <input type="text" className="form-control" id="contact_name" readOnly={isReadonly()} value={emergencyContactItem?.contact_name|| ""} name="contact_name" 
                                                        onChange={(e) => setEmergencyContact((prev) => {
                                                                    const updated = [...prev];
                                                                    updated[index] = {
                                                                    ...updated[index],
                                                                    contact_name: e.target.value,
                                                                    };
                                                                    return updated;
                                                                })} />
                                                        {emergencyFieldErrors.contact_name && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}

                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row" style={{ alignItems: "center" }}>
                                                <div className="col-md-3">
                                                    <div className="form_box">
                                                        <label htmlFor="exampleFormControlInput1" className="form-label" >Relation<span className='req_text'>*</span> :  </label>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form_box">
                                                        <select id="relation" name="relation" 
                                                        value={emergencyContactItem?.relation?.id|| ""}
                                                        onChange={(e) =>
                                                            setEmergencyContact((prev) => {
                                                                const updated = [...prev];
                                                                updated[index] = {
                                                                    ...updated[index],
                                                                    relation: {
                                                                        ...updated[index].relation,
                                                                        id: parseInt(e.target.value)
                                                                    }
                                                                };
                                                                return updated;
                                                            })
                                                        }>
                                                            {(!emergencyContactItem || !emergencyContactItem.relation || emergencyContactItem.relation.id==0) && <option value="">Select Relation</option>}
                                                            {emergencyContactRelation.map((relationsType, index) => (
                                                                <option value={relationsType.id} key={relationsType.id} disabled={isReadonly()}>{relationsType.relation_type}</option>
                                                            ))}
                                                        </select>
                                                        {emergencyFieldErrors.relation && <span className='error' style={{ color: "red", fontSize: "12px" }}>required*</span>}

                                                    </div>
                                                </div>

                                            </div>
                                           </div>) }

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-lg-12" style={{ textAlign: "right" }}><input type='submit' value="Update" disabled={isReadonly()} className={`red_button ${isLoading}:"loading":""`} onClick={handleSubmit} /></div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </>
    )
}


async function getRelations() {

    let query = supabase
        .from('leap_relations')
        .select();

    const { data, error } = await query;
    if (error) {
        console.log(error);

        return [];
    } else {


        return data;
    }
}