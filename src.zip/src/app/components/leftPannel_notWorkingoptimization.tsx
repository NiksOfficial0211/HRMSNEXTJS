"use client";

import React, { useEffect, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  pageURL_addUserBasicDetailForm,
  pageURL_announcementListingPage,
  pageURL_assetListing,
  pageURL_attendanceList,
  pageURL_clientAdminSettingsPage,
  pageURL_clientProfilePage,
  pageURL_companyDocumentsPage,
  pageURL_createAnnouncement,
  pageURL_dashboard,
  pageURL_employeeDocumentsPage,
  pageURL_leaveListingPage,
  leftMenuAddEmployeePageNumbers,
  leftMenuAnnouncementPageNumbers,
  leftMenuAssetsPageNumbers,
  leftMenuAttendancePageNumbers,
  leftMenuDashboardPageNumbers,
  leftMenuDocumentsPageNumbers,
  leftMenuDocumentsSub1PageNumbers,
  leftMenuDocumentsSub2PageNumbers,
  leftMenuEmployeeListPageNumbers,
  leftMenuHRPageNumbers,
  leftMenuLeavePageNumbers,
  leftMenuMessagePageNumbers,
  leftMenuNoticePageNumbers,
  leftMenuProfilePageNumbers,
  leftMenuProjectMGMTPageNumbers,
  leftMenuteamMeetPageNumbers,
  pageURL_userList,
  leftMenuPayrollSub1PageNumbers,
  leftMenuPayrollSub2PageNumbers,
  pageURL_companyPayroll,
  pageURL_customizePayroll,
  leftMenuCompanyPayrollPageNumbers,
  leftMenuProjectsSub1PageNumbers,
  leftMenuProjectsSub2PageNumbers,
  pageURL_ProjectsPage,
  pageURL_ProjectsTaskPage,
  leftMenuAdminSettingsPageNumbers,
  pageURL_userEmpDashboard,
  pageURL_userAttendance,
  leftMenuUserDashboard,
  pageURL_userTaskListingPage,
  pageURL_userLeave,
  leftMenuUserLeave,
  leftMenuUserAttendance,
  leftMenuUserTask,
  leftMenuUserAsset,
  leftMenuUserDocuments,
  pageURL_userAsset,
  pageURL_userDoc,
  pageURL_userOrganisation,
  leftMenuUserOrg,
  pageURL_userSupport,
  leftMenuUserSupport,
  leftMenuCustomerListPageNumbers,
  pageURL_clientAdminSupport,
  pageURL_orgHierarchy,
  pageURL_customerListPage,
  leftMenuOrgHierarchy,
  pageURL_userAnnouncement,
  leftMenuUserAnnouncement,
} from "../pro_utils/stringRoutes";
import { useGlobalContext } from "../contextProviders/loggedInGlobalContext";
import supabase from "../api/supabaseConfig/supabase";
import { staticIconsBaseURL } from "../pro_utils/stringConstants";

// --- types ---
type LeftPanelProps = {
  menuIndex: number;
  subMenuIndex: number;
  showLeftPanel: boolean;
  rightBoxUI: React.ReactNode;
};

interface UserPermissionModel {
  permission_id: string;
  is_allowed: boolean;
}

// --- helper: small route -> menu mapping ---
const leftRouteMap: { index: number; routes: string[] }[] = [
  { index: leftMenuDashboardPageNumbers, routes: [pageURL_dashboard, pageURL_userEmpDashboard] },
  { index: leftMenuAssetsPageNumbers, routes: [pageURL_assetListing] },
  { index: leftMenuDocumentsPageNumbers, routes: [pageURL_companyDocumentsPage, pageURL_employeeDocumentsPage] },
  { index: leftMenuAnnouncementPageNumbers, routes: [pageURL_announcementListingPage, pageURL_createAnnouncement] },
  { index: leftMenuLeavePageNumbers, routes: [pageURL_leaveListingPage, pageURL_userLeave] },
  { index: leftMenuEmployeeListPageNumbers, routes: [pageURL_userList] },
  { index: leftMenuAddEmployeePageNumbers, routes: [pageURL_addUserBasicDetailForm] },
  { index: leftMenuAttendancePageNumbers, routes: [pageURL_attendanceList, pageURL_userAttendance] },
  { index: leftMenuProfilePageNumbers, routes: [pageURL_clientProfilePage] },
  { index: leftMenuCompanyPayrollPageNumbers, routes: [pageURL_companyPayroll, pageURL_customizePayroll] },
  { index: leftMenuProjectMGMTPageNumbers, routes: [pageURL_ProjectsPage, pageURL_ProjectsTaskPage] },
  { index: leftMenuAdminSettingsPageNumbers, routes: [pageURL_clientAdminSettingsPage] },
  { index: leftMenuUserDashboard, routes: [pageURL_userEmpDashboard] },
  { index: leftMenuUserTask, routes: [pageURL_userTaskListingPage] },
  { index: leftMenuUserAsset, routes: [pageURL_userAsset] },
  { index: leftMenuUserDocuments, routes: [pageURL_userDoc] },
  { index: leftMenuUserOrg, routes: [pageURL_userOrganisation] },
  { index: leftMenuUserSupport, routes: [pageURL_userSupport, pageURL_clientAdminSupport] },
  { index: leftMenuCustomerListPageNumbers, routes: [pageURL_customerListPage] },
  { index: leftMenuOrgHierarchy, routes: [pageURL_orgHierarchy] },
  { index: leftMenuUserAnnouncement, routes: [pageURL_userAnnouncement] },
];

const subRouteMap: { index: number; route: string }[] = [
  { index: leftMenuDocumentsSub1PageNumbers, route: pageURL_companyDocumentsPage },
  { index: leftMenuDocumentsSub2PageNumbers, route: pageURL_employeeDocumentsPage },
  { index: leftMenuPayrollSub1PageNumbers, route: pageURL_companyPayroll },
  { index: leftMenuPayrollSub2PageNumbers, route: pageURL_customizePayroll },
  { index: leftMenuProjectsSub1PageNumbers, route: pageURL_ProjectsPage },
  { index: leftMenuProjectsSub2PageNumbers, route: pageURL_ProjectsTaskPage },
];

// --- component ---
function LeftPannel({ menuIndex, subMenuIndex, showLeftPanel, rightBoxUI }: LeftPanelProps) {
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();
  const [permissionData, setPermissionData] = useState<UserPermissionModel[]>();

  const [showDocSubMenu, setShowDocSubMenu] = useState(false);
  const [showProjectSuMenus, setShowProjectSuMenus] = useState(false);
  const [showPayrollSubMenus, setShowPayrollSubMenus] = useState(false);

  const {
    contaxtBranchID,
    contextClientID,
    contextRoleID,
    isAdmin,
    contextUserName,
    contextCustomerID,
    contextEmployeeID,
    contextLogoURL,
    contextProfileImage,
    contextCompanyName,
    dashboard_notify_activity_related_id,
    dashboard_notify_cust_id,
    setGlobalState,
  } = useGlobalContext();

  // fetch permissions (keeps separate and inexpensive)
  useEffect(() => {
    let mounted = true;
    (async function fetchPerms() {
      try {
        const user = await getUserPermission(contextClientID);
        if (mounted) setPermissionData(user || []);
      } catch (e) {
        if (mounted) setPermissionData([]);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [contextClientID]);

  // compute selection from pathname (no clicks required)
  const { selectedLeft, selectedSub } = useMemo(() => {
    let left = menuIndex ?? null;
    let sub = subMenuIndex ?? null;

    if (pathname) {
      // left menu
      for (const m of leftRouteMap) {
        for (const r of m.routes) {
          if (r && pathname.startsWith(r)) {
            left = m.index;
            break;
          }
        }
        if (left === m.index) break;
      }

      // sub menu
      for (const s of subRouteMap) {
        if (s.route && pathname.startsWith(s.route)) {
          sub = s.index;
          break;
        }
      }
    }

    return { selectedLeft: left, selectedSub: sub };
  }, [pathname, menuIndex, subMenuIndex]);

  // when the URL indicates a submenu is active, expand it automatically
  useEffect(() => {
    if (selectedSub === leftMenuDocumentsSub1PageNumbers || selectedSub === leftMenuDocumentsSub2PageNumbers) {
      startTransition(() => setShowDocSubMenu(true));
    }
    if (selectedSub === leftMenuPayrollSub1PageNumbers || selectedSub === leftMenuPayrollSub2PageNumbers) {
      startTransition(() => setShowPayrollSubMenus(true));
    }
    if (selectedSub === leftMenuProjectsSub1PageNumbers || selectedSub === leftMenuProjectsSub2PageNumbers) {
      startTransition(() => setShowProjectSuMenus(true));
    }
  }, [selectedSub]);

  const checkPermission = (permissionId: any) => {
    if (!permissionData) return false;
    return permissionData.some((p) => p.permission_id === permissionId && p.is_allowed);
  };

  // small UI helpers to avoid inline objects/handlers that cause re-renders
  const menuClass = (index?: number) => (selectedLeft === index ? "left_selected" : "");
  const subClass = (index?: number) => (selectedSub === index ? "submenu-item-selected" : "submenu-item");

  if (!showLeftPanel) return null;

  return (
    <div id="middle_box" className={"middle_box"}>
      <div className={`${isPending ? "cursorLoading nw_user_panel_mainbox" : "nw_user_panel_mainbox"}`}>
        <div className="left_mainbox">
          <div className="left_inner">
            <div className="left_sticky">
              {contextRoleID == "2" && isAdmin == "1" ? (
                <div className="left_menubox">
                  <Link href={pageURL_dashboard} className={menuClass(leftMenuDashboardPageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/home_icon.png)" }} />
                    <div className="left_menutext">Dashboard</div>
                  </Link>

                  <Link href={pageURL_assetListing} className={menuClass(leftMenuAssetsPageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/attendance_icon.png)" }} />
                    <div className="left_menutext">Assets</div>
                  </Link>

                  {/* Documents header (expand only) */}
                  <div
                    className={`left_menuitem ${menuClass(leftMenuDocumentsPageNumbers)}`}
                    onClick={() => {
                      startTransition(() => {
                        setShowDocSubMenu((s) => !s);
                        setShowProjectSuMenus(false);
                        setShowPayrollSubMenus(false);
                      });
                    }}
                  >
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/document_icon.png)" }} />
                    <div className={selectedLeft === leftMenuDocumentsPageNumbers && showDocSubMenu || ((selectedSub === leftMenuDocumentsSub1PageNumbers || selectedSub === leftMenuDocumentsSub2PageNumbers) && showDocSubMenu) ? "left_menutext active" : "left_menutext"}>
                      <div className="submenu_innerbox">
                        <div>Documents</div>
                      </div>
                      <div className="submenu_otherbox">
                        <Link href={pageURL_companyDocumentsPage} prefetch className={subClass(leftMenuDocumentsSub1PageNumbers)}>
                          Company Document
                        </Link>
                        <Link href={pageURL_employeeDocumentsPage} prefetch className={subClass(leftMenuDocumentsSub2PageNumbers)}>
                          Employee Document
                        </Link>
                      </div>
                    </div>
                  </div>

                  <Link href={pageURL_announcementListingPage} className={menuClass(leftMenuAnnouncementPageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/announcement_icon.png)" }} />
                    <div className="left_menutext">Announcement/ News</div>
                  </Link>

                  <Link href={pageURL_leaveListingPage} className={menuClass(leftMenuLeavePageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/leave_icon.png)" }} />
                    <div className="left_menutext">Leave</div>
                  </Link>

                  <Link href={pageURL_userList} className={menuClass(leftMenuEmployeeListPageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/allemployee_icon.png)" }} />
                    <div className="left_menutext">All Employees</div>
                  </Link>

                  <Link href={pageURL_addUserBasicDetailForm} className={menuClass(leftMenuAddEmployeePageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/addemployee_icon.png)" }} />
                    <div className="left_menutext">Add Employee</div>
                  </Link>

                  <Link href={pageURL_attendanceList} className={menuClass(leftMenuAttendancePageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/attendance_icon.png)" }} />
                    <div className="left_menutext">Attendance</div>
                  </Link>

                  <Link href={pageURL_clientProfilePage} className={menuClass(leftMenuProfilePageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/human_icon.png)" }} />
                    <div className="left_menutext">Profile</div>
                  </Link>

                  {/* Payroll header */}
                  <div
                    className={`left_menuitem ${menuClass(leftMenuCompanyPayrollPageNumbers)}`}
                    onClick={() => startTransition(() => {
                      setShowPayrollSubMenus((s) => !s);
                      setShowDocSubMenu(false);
                      setShowProjectSuMenus(false);
                    })}
                  >
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/payroll_icon.png)" }} />
                    <div className={selectedLeft === leftMenuCompanyPayrollPageNumbers && showPayrollSubMenus || ((selectedSub === leftMenuPayrollSub1PageNumbers || selectedSub === leftMenuPayrollSub2PageNumbers) && showPayrollSubMenus) ? "left_menutext active" : "left_menutext"}>
                      <div className="submenu_innerbox">
                        <div>Payroll</div>
                      </div>
                      <div className="submenu_otherbox">
                        <Link href={pageURL_companyPayroll} prefetch className={subClass(leftMenuPayrollSub1PageNumbers)}>Company Payroll</Link>
                        <Link href={pageURL_customizePayroll} prefetch className={subClass(leftMenuPayrollSub2PageNumbers)}>Customize Payroll</Link>
                      </div>
                    </div>
                  </div>

                  {/* Project Management header */}
                  <div
                    className={`left_menuitem ${menuClass(leftMenuProjectMGMTPageNumbers)}`}
                    onClick={() => startTransition(() => {
                      setShowProjectSuMenus((s) => !s);
                      setShowDocSubMenu(false);
                      setShowPayrollSubMenus(false);
                    })}
                  >
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/work_icon.png)" }} />
                    <div className={selectedLeft === leftMenuProjectMGMTPageNumbers && showProjectSuMenus || ((selectedSub === leftMenuProjectsSub1PageNumbers || selectedSub === leftMenuProjectsSub2PageNumbers) && showProjectSuMenus) ? "left_menutext active" : "left_menutext"}>
                      <div className="submenu_innerbox">
                        <div>Project Management</div>
                      </div>
                      <div className="submenu_otherbox">
                        <Link href={pageURL_ProjectsPage} prefetch className={subClass(leftMenuProjectsSub1PageNumbers)}>Projects</Link>
                        <Link href={pageURL_ProjectsTaskPage} prefetch className={subClass(leftMenuProjectsSub2PageNumbers)}>Task Management</Link>
                      </div>
                    </div>
                  </div>

                  <Link href={pageURL_clientAdminSupport} className={menuClass(leftMenuUserSupport)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/help_icon.png)` }} />
                    <div className="left_menutext">Help</div>
                  </Link>

                  <Link href={pageURL_orgHierarchy} className={menuClass(leftMenuOrgHierarchy)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/organization_icon.png)` }} />
                    <div className="left_menutext">Organization Hierarchy</div>
                  </Link>

                  <Link href={pageURL_customerListPage} className={menuClass(leftMenuCustomerListPageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/setting_icon.png)" }} />
                    <div className="left_menutext">Our Customers</div>
                  </Link>

                  <Link href={pageURL_clientAdminSettingsPage} className={menuClass(leftMenuAdminSettingsPageNumbers)}>
                    <div className="left_menuicon" style={{ backgroundImage: "url(/images/left-menu/setting_icon.png)" }} />
                    <div className="left_menutext">Admin Settings</div>
                  </Link>
                </div>
              ) : (
                // non-admin user menu
                <div className="left_menubox">
                  <Link href={pageURL_userEmpDashboard} className={menuClass(leftMenuUserDashboard)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/home_icon.png)` }} />
                    <div className="left_menutext">Dashboard</div>
                  </Link>

                  <Link href={pageURL_userAttendance} className={menuClass(leftMenuUserAttendance)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/attendance_icon.png)` }} />
                    <div className="left_menutext">Attendance</div>
                  </Link>

                  <Link href={pageURL_userTaskListingPage} className={menuClass(leftMenuUserTask)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/attendance_icon.png)` }} />
                    <div className="left_menutext">Task</div>
                  </Link>

                  <Link href={pageURL_userLeave} className={menuClass(leftMenuUserLeave)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/leave_icon.png)` }} />
                    <div className="left_menutext">Leave</div>
                  </Link>

                  <Link href={pageURL_userAsset} className={menuClass(leftMenuUserAsset)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/attendance_icon.png)` }} />
                    <div className="left_menutext">Asset</div>
                  </Link>

                  <Link href={pageURL_userDoc} className={menuClass(leftMenuUserDocuments)}>
                    <div className="left_menuicon" style={{ backgroundImage: `url(/images/left-menu/document_icon.png)` }} />
                    <div className="left_menutext">Documents</div>
                  </Link>

                  {contextRoleID !== "2" && (
                    <Link href={pageURL_userOrganisation} className={menuClass(leftMenuUserOrg)}>
                      <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/allemployee_icon.png)` }} />
                      <div className="left_menutext">About Organization</div>
                    </Link>
                  )}

                  {contextRoleID !== "2" && (
                    <Link href={pageURL_userAnnouncement} className={menuClass(leftMenuUserAnnouncement)}>
                      <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/announcement_icon.png)` }} />
                      <div className="left_menutext">Announcement</div>
                    </Link>
                  )}

                  {contextRoleID !== "2" && (
                    <Link href={pageURL_userSupport} className={menuClass(leftMenuUserSupport)}>
                      <div className="left_menuicon" style={{ backgroundImage: `url(${staticIconsBaseURL}/images/left-menu/help_icon.png)` }} />
                      <div className="left_menutext">Help</div>
                    </Link>
                  )}
                </div>
              )}

              <div onClick={() => startTransition(() => {})} className="toggle_box" />
            </div>
          </div>
        </div>

        <div className="right_mainbox">{rightBoxUI}</div>
      </div>
    </div>
  );
}

export default React.memo(LeftPannel);

// --- helper: DB permission loader ---
async function getUserPermission(clientId: string) {
  try {
    const query = supabase.from("leap_client_module_permission").select(`*`).eq("client_id", clientId);
    const { data, error } = await query;
    if (error) return [];
    return data || [];
  } catch (e) {
    return [];
  }
}
