interface EmployeeBankDetails {
    id: number
    created_at: string
    customer_id: number
    client_id: number
    bank_name: string
    account_number: string
    IFSC_code: string
    UAN_number: string
    ESIC_number: string
    PAN_number: string
    updated_at: string
    TIN_number: number
    security_insurance_no: number
}