interface AppInfoModel{
    platform:any;
    version:any;
    force_update:any;
    live_app_url:any
    client_id:any;
    company_logo:any;
    company_name:any;
    compnay_websit:any;
    primary_color:any;
    secondary_color:any;
    show_dashboard:any
}