interface LeaveTypeCount{
    leaveTypeId:number
    leaveType: number
    leaveAllotedCount: any
    totalAppliedLeaveDays:any
    leaveBalance:any
    isPaid:any
    color_code:any
}